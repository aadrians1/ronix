                       All in ONE solution
---------------------------------------------------------------------


For flashing :

1. run Tirum_flasher.exe
2. Choose aplication file
3. Choose loader (always use uniloader.bin)
4. Choose product (phone type)
5. Connect phone
6. Start download



Flash files :

Mars.bin - Mars flash -central europe lg
ARIA.bin - Aria @ flash file -central europe lg
Galaxy-astral.bin - Galaxy and Astral flash file -central europe lg




Fors mars flashing U must at first start troky eprom R/W and download 
MarsE.bin to mobile. Otherwise U get Contact provider.

-----------------------------------------------------------------------
